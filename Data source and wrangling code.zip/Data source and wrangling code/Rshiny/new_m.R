library(shiny)
library(ggplot2)
library(shinythemes)
library(plotly)
library(hexbin)
library(tableHTML)

# you need import the following data set (country and migrantall) or Rdata
# and the migrantall have several sheet, you need to import all of them to the global environment
# if you want to update the data, you need to have the same dataset name and format

# rename the document of top country of birth 
names(country) <- c('top1','top1_p','top1_pp','top2','top2_p','top2_pp','top3','top3_p','top3_pp','top4','top4_p','top4_pp','top5','top5_p','top5_pp','suburb')
country_name <- speak$country

# a globle function to get the column name and store in a vector
row_list <- function(data11){
  aa <- c()
  for (i in 1:range(ncol(data11))[1]) {
    aa <- append(aa,data11[[1,i]])
  }
  return(aa)
}

# ui
ui <- navbarPage("History of Migration",id="nav", theme = shinytheme("paper"), collapsible = TRUE,
                 
                 tabPanel("Profile of migrant(Overall)",
                          
                          ## the title of the page
                          h3("Migrant Profile"),
  
                          fluidRow(
                            
                            column(
                              4,
                              ## select bar
                              selectInput("overall", "Attribute：",
                                          choices = c("Top 10 country of migrant",  "New Citizen number"
                                                      ,"The number of different family type")),
                              helpText(
                                       "Note: This dashboard shows statistics about migrants in Victoria.",
                                       "This interface shows some basic statistics.",
                                       "The second page is about the characteristics of migrants from different countries.",
                                       "The third page shows the distribution of migrants from different countries in Melbourne."),
                              tags$a(href = "http://www.abs.gov.au/AUSSTATS/abs@.nsf/DetailsPage/3415.02018?OpenDocument", 
                                     "Source: Australian Bureau of Statistics", target = "_blank")
                            ),
                            column(
                              8,
                              plotlyOutput("overplot")
                              
                            )
                            
                          )

                 ),
                 
                 tabPanel("Profile of migrant(By country)",
                          
                          ## the title of the page
                          h3("The profile of different country migrant"),
                          
                          fluidRow(
                            column(
                              4,
                              
                              selectInput("nation", "Country：",
                                          choices = country_name),
                              selectInput("attribute", "Attribute：",
                                          choices = c("Migrant type",  "New citizenship"
                                                      ,"Speaking skill"))
                            ),
                            column(
                              8,
                              plotlyOutput("rockplot")
                            )
                                
                          )
 
                 ),
                 tabPanel(
                   "Distribution",
                   h3("Nationality distribution"),
                   
                   fluidRow(
                     column(
                       4,
                       
                       selectInput(
                         "country", "Country：",
                         choices = sort(unique(country[['top1']]))
                       ),
                       ## the output is based on input
                       uiOutput("xx" ),
                       uiOutput("yy" ),
                       column(width = 11,
                              verbatimTextOutput("rank")
                       ),
                       checkboxInput("summary", "Ranking", TRUE)
                     ),
                     column(
                       8,
                       plotlyOutput("dis_plot")
                     )
                     
                   )
                 )
)

server <- function(input, output) {
  
  # actually all the datasets are in the global environment
  # this part just like to make sure the condition
  datasetInput <- reactive({
    if(input$attribute=="Migrant type"){
      return(type1)
    }
    if(input$attribute=="New citizenship"){
      return(citizen)
    }
    if(input$attribute=="Speaking skill"){
      return(speak)
    }
  })
  
  # the out put of the first page
  output$overplot <- renderPlotly({
    
    if(input$overall=="Top 10 country of migrant"){
      over_data <- total
      over_data$country<-reorder(over_data$country,-over_data$`migrant number`)
    }
    if(input$overall=="New Citizen number"){
      over_data <- newcitizen
    }
    if(input$overall=="The number of different family type"){
      over_data <- family
    }
    
    dataplot1 <- over_data
    ## rename the column that will be used in tooltip
    names(dataplot1) <- c('x','number')
    
    ## bar chart
    pp <- ggplot(data=dataplot1, aes(x=x,y=number, fill=x, a=x, b=number))+
      geom_bar(stat="identity",width=0.5)+
      xlab(colnames(over_data)[1])+
      ylab('number')+
      ggtitle(paste(input$overall, 'between 2000 and 2016'))+
      theme(legend.position = "none",panel.grid.major = element_line(colour = "grey92"), axis.text = element_text(size = rel(0.7)),panel.grid.minor = element_line(colour = "grey92"),panel.background = element_rect(fill = "white"), axis.text.x = element_text(angle = 30))
    
    ## set tooltip  
    ggplotly(pp,tooltip = c("a", "b"))
    
  })
  
  # the plot of the second page
  output$rockplot <- renderPlotly({
    
    col1 <- input$attribute
    data11 <- colnames(datasetInput())[2:(ncol(datasetInput())-1)]
    Attributes <- data11
    ## get subset of target value
    tempp <- datasetInput()[which(datasetInput()$country==input$nation),colnames(datasetInput())[2:(ncol(datasetInput())-1)]]
    data22 <- row_list(tempp)
    final_data <- data.frame(Attributes,data22)
    ## rename the data for tooltips
    names(final_data) <- c("x", "number")
    
    ## barchart
    p <- ggplot(data=final_data, aes(x=x,y=number,fill=x, a=x, b=number))+
      geom_bar(stat="identity",width=0.5)+
      xlab(col1)+
      ylab('number')+
      ggtitle(paste(input$attribute, paste("of",input$nation)))+
      theme(legend.position = "none",axis.text = element_text(size = rel(0.7)),panel.grid.major = element_line(colour = "grey92"),panel.grid.minor = element_line(colour = "grey92"),panel.background = element_rect(fill = "white"),axis.text.x = element_text(angle = 30))
    ggplotly(p,tooltip = c("a", "b"))
  })
  
  output$xx <- renderUI({
    sub1 <- subset(country, top1==input$country)
    name1 <- sort(sub1[['suburb']])
    selectInput("suburb", "Suburb:", name1)
  })
  # to get the maximum number of suburb for a certain country
  output$yy <- renderUI({
    if(input$summary){
      cname <- paste("Top suburb of", input$country)
      fname <- paste(cname, "in MEL")
      names(country) <- c('top1','top1_p','top1_pp','top2','top2_p','top2_pp','top3','top3_p','top3_pp','top4','top4_p','top4_pp','top5','top5_p','top5_pp','suburb')
      sub <- subset(country, top1==input$country)
      temppp<-data.frame(sub[['suburb']],sub[['top1_p']])
      maxno <- nrow(temppp)
      if(maxno > 5){
        maxno <- 5
      }
      sliderInput("obs",label=fname,min=1,max=maxno,value = 1,step = 1)
    }
  })
  # output the ranking of suburb about the population of country of birth 
  output$rank <- renderPrint({
    names(country) <- c('top1','top1_p','top1_pp','top2','top2_p','top2_pp','top3','top3_p','top3_pp','top4','top4_p','top4_pp','top5','top5_p','top5_pp','suburb')
    sub <- subset(country, top1==input$country)
    temp<-data.frame(sub[['suburb']],sub[['top1_p']])
    names(temp)<-c('suburb','population')
    a <- temp[order(temp[,2],decreasing=TRUE),c(1,2)]
    rownames(a) <- 1:nrow(a)
    if(input$summary){
      return(head(a, input$obs))
    }
    
  })
  # the third barchart
  output$dis_plot <- renderPlotly({
    ## wrangling the data to suitable format
    temp1 <- subset(country, suburb==input$suburb)
    nation <- c()
    value <- c()
    for (i in c('top1','top2','top3','top4','top5')) {
      nation <- append(nation, temp1[[i]])
    }
    for (i in c('top1_p','top2_p','top3_p','top4_p','top5_p')) {
      value <- append(value, temp1[[i]])
    }
    data1 <- data.frame(nation,value)
    names(data1)<-c('country','population')
    data1$country<-reorder(data1$country,-data1$population)
    
    p <- ggplot(data=data1, aes(x=country,y=population,fill=country, a=country, b=population))+
      geom_bar(stat="identity",width=0.5)+
      ggtitle(paste("The top five country of birth in",input$suburb))+
      theme(legend.position = "none",axis.text = element_text(size = rel(0.7)),panel.grid.major = element_line(colour = "grey92"),panel.grid.minor = element_line(colour = "grey92"),panel.background = element_rect(fill = "white"),axis.text.x = element_text(angle = 30))
    ggplotly(p,tooltip = c("a", "b"))
  })
  
}

shinyApp(ui, server)
